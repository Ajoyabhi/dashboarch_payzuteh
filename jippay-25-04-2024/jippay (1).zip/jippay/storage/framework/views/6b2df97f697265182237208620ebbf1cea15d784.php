<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Page Container START -->

<div class="page-container">

    <!-- Content Wrapper START -->

    <div class="main-content">

        <div class="row">

            <div class="col-md-12 col-lg-12">

                <div class="card">

                    <div class="card-body">

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>

                        <?php if(session('success')): ?>
                        <div class="alert alert-success mb-1 mt-1">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                        <div class="alert alert-danger mb-1 mt-1">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?>

                        <div class="d-flex justify-content-between align-items-center">
                            <h5>Payout Requests</h5>
                        </div>

                        <div class="m-t-30">

                            <div class="table-responsive-md table-responsive-sm table-responsive">

                                <table class="table table-hover table-bordered" id="datatable">

                                    <thead>

                                        <tr>

                                            <th>SI.NO</th>

                                            <th>OrderId</th>

                                            <th>Date</th>

                                            <th>User</th>

                                            <th>Descrption</th>

                                            <th>Amount</th>

                                            <th>Wallet balance</th>

                                            <th>Status</th>

                                        </tr>

                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $payout_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($payout_list->id); ?></th>
                                            <td><?php echo e($payout_list->ref_number); ?></td>
                                            <td><?php echo e(date("d-m-Y", strtotime($payout_list->created_at))); ?></td>
                                            <td><?php echo e($payout_list->name); ?></td>
                                            <td><?php echo e($payout_list->description); ?></td>
                                            <td><?php echo e($payout_list->amount); ?></td>
                                            <td><?php echo e(number_format($payout_list->wallet_bal,2)); ?></td>
                                            <td>
                                                <?php if($payout_list->status == 0): ?>
                                                <span class="btn btn-warning btn-sm" data-toggle="modal"
                                                    data-target="#setting_<?php echo e($payout_list->id); ?>"> Pending </span>
                                                <?php elseif($payout_list->status == 1): ?>
                                                <span class="btn btn-success btn-sm"> Approved </span>
                                                <?php else: ?>
                                                <span class="btn btn-danger btn-sm"> Rejected </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>

                                        
                                        <div class="modal fade" id="setting_<?php echo e($payout_list->id); ?>">

                                            <div class="modal-dialog modal-dialog-scrollable">

                                                <div class="modal-content">

                                                    <div class="modal-header">

                                                        <h5 class="modal-title" id="exampleModalScrollableTitle">Status
                                                        </h5>

                                                        <button type="button" class="close" data-dismiss="modal">

                                                            <i class="anticon anticon-close"></i>

                                                        </button>

                                                    </div>

                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('admin.payoutStatus',$payout_list->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label for="inputAddress">Status</label>
                                                                <input type="hidden" name="id"
                                                                    value="<?php echo e($payout_list->id); ?>">
                                                                <select name="status" id="status" class="form-control" required>
                                                                    <option value="">-- Select Status --</option>
                                                                    <option value="1">Approve</option>
                                                                    <option value="2">Reject</option>
                                                                </select>
                                                            </div>

                                                            <div class="form-group admin_code_div"
                                                                style="display: none;" id="admin_code_div">
                                                                <label for="inputAddress">Admin Code</label>
                                                                <input name="admin_code" id="admin_code"
                                                                    class="form-control" maxlength="10">
                                                            </div>

                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-default"
                                                                    data-dismiss="modal">Close</button>
                                                                <button type="submit" name="submit"
                                                                    class="btn btn-primary">Submit</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                        

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<!-- Content Wrapper END -->

<!-- model -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<link href="https://cdn.datatables.net/v/dt/dt-1.13.5/datatables.min.css" rel="stylesheet">

<script src="https://cdn.datatables.net/v/dt/dt-1.13.5/datatables.min.js"></script>

<script type="text/javascript">

    $(document).ready(function () {
        let table = new DataTable('#datatable');

        $(document).on('change', '#status', function () {
            var _this = $(this);
            var staus_val = _this.val();
            if (staus_val == 1) {
                $('.admin_code_div').show();
                $('.admin_code').attr('required', true);
            } else {
                $('.admin_code_div').hide();
                $('.admin_code').attr('required', false);
            }
        });
    });
</script>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apipaydexsolutio/public_html/jippay/resources/views/admin/payoutlist.blade.php ENDPATH**/ ?>