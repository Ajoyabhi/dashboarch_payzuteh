<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-container">

    <!-- Content Wrapper START -->

    <div class="main-content">

        <div class="page-header">

            <h2 class="header-title">Wallet Topup</h2>

            <div class="header-sub-title">

                <nav class="breadcrumb breadcrumb-dash">

                    <a href="<?php echo e(url('/admin/dashboard')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>                    

                    <span class="breadcrumb-item active">Wallet Topup</span>

                </nav>

            </div>

        </div>

        <div class="card">

            <div class="card-body">

                <?php if(session('success')): ?>

                <div class="alert alert-success mb-1 mt-1">

                    <?php echo e(session('success')); ?>


                </div>

                <?php endif; ?>

                <form action="<?php echo e(url('/admin/wallet-topup')); ?>" method="POST" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>

                    <div class="form-row">

                        <div class="col-md-4 mb-3">

                            <label for="">User</label>

                            <select class="form-control" name="user">

                                <option value="">Select User</option>

                                <?php if(!empty($users)): ?>

                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($rows->id); ?>"><?php echo e($rows->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    

                                <?php endif; ?>                                

                            </select>

                            <div class="invalid-feedback" style="display: block!important;">

                                <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                    <?php echo e($message); ?>


                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                        <div class="col-md-4 mb-3">

                            <label for="">Amount</label>

                            <input type="text" class="form-control is-invalid1" maxlength="6"  id="amount" name="amount" placeholder="Enter Amount" onKeyUp="return getAmountVal();">

                            <div class="invalid-feedback" style="display: block!important;">

                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                            <div style="font-size:17px !important" class="text-danger" id="amountInWord"></div>
                        </div>

                        <div class="col-md-4 mb-3">

                            <label for="">Remark</label>

                            <input type="text" class="form-control is-invalid1" id="remark" name="remark" value="WALLETLOAD" >

                            <div class="invalid-feedback" style="display: block!important;">

                                <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <?php echo e($message); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                        <div class="form-group text-center">

                            <button class="btn btn-primary">Request</button>

                        </div>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>
<script>
    var a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
    var b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];

function inWords (num) {
    if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'And ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only ' : '';
    return str;
}

document.getElementById('amount').onkeyup = function () {
    document.getElementById('amountInWord').innerHTML = inWords(document.getElementById('amount').value);
};

</script>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jippay\resources\views/admin/wallet-topup.blade.php ENDPATH**/ ?>