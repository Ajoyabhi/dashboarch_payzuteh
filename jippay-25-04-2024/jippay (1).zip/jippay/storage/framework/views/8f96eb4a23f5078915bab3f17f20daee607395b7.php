<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Page Container START -->
            <div class="page-container">
                <!-- Content Wrapper START -->
                <div class="main-content ag-courses_box">
                    <div class="row">
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-user"></i>
                              <span>Total Users</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($totalUsers); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-dollar"></i>
                              <span>Available balance</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($usersWithBalances); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-dollar"></i>
                              <span>Usable Balance</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                              <?php echo e(round(($usersWithBalances)-($usableBalnce), 2)); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-arrow-down"></i>
                              <span>Today Payin</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($todayPayin); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-arrow-up"></i>
                              <span>Today Payout</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($todayPayout); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                            <i class="anticon anticon-dollar"></i>
                              <span>Today Profit</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($todayProfit); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                            <i class="anticon anticon-dollar"></i>
                              <span>Total Profit</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($totalProfit); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-arrow-down"></i>
                              <span>Total Payin</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($totalPayin); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                        <div class="col-md-6 col-lg-3 ag-courses_item">
                          <a href="#" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>
                            <div class="ag-courses-item_title">
                              <i class="anticon anticon-arrow-up"></i>
                              <span>Total Payout</span>
                            </div>
                            <div class="ag-courses-item_date-box">
                              <span class="ag-courses-item_date">
                                <?php echo e($totalPayout); ?>

                              </span>
                            </div>
                          </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-4">
                                            <h5 class="card-heading">Recent Transactions</h5>
                                        </div>
                                        <div class="col text-right">
                                            <div class="container">
                                                  <a href="<?php echo e(url('/admin/wallet-report')); ?>" class="new-button">View All</a>
                                            </div> 
                                        </div>
                                    </div>
                                    <div class="m-t-30">
                                        <div class="tbl-header">
                                            <table class="table-bordered" cellpadding="0" cellspacing="0" border="0">
                                              <thead>
                                                <tr>
                                                  <th>Type</th>
                                                  <th>Date</th>
                                                  <th>OrderId</th>
                                                  <th>User</th>
                                                  <th>Descrption</th>
                                                  <th>Amount</th>
                                                  <th>Wallet balance</th>
                                                  <th>Status</th>
                                                </tr>
                                              </thead>
                                            </table>
                                          </div>
                                          <div class="tbl-content">
                                            <table class="table-bordered" cellpadding="0" cellspacing="0" border="0">
                                              <tbody>
                                                    <?php if(!empty($usertransaction)): ?>
                                                        <?php $__currentLoopData = $usertransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <?php if($rows->type == "CREDIT"): ?>
                                                                    <button class="btn btn-icon btn-success">
                                                                        <i class="anticon anticon-arrow-down"></i>
                                                                    </button>
                                                                <?php else: ?>
                                                                    <button class="btn btn-icon btn-danger">
                                                                        <i class="anticon anticon-arrow-up"></i>
                                                                    </button>
                                                                <?php endif; ?>
                                                            </td>   
                                                            <td><?php echo e($rows->created_at); ?></td>
                                                            <td><?php echo e($rows->orderId); ?></td>
                                                            <td><?php echo e($rows->user->name); ?></td>
                                                                                                                             
                                                            <td><?php echo e($rows->remark); ?></td>
                                                            <td><?php echo e($rows->amount); ?></td>     
                                                            <td><?php echo e($rows->walletBalance); ?></td> 
                                                            <td><?php echo e($rows->status); ?></td>                                           
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                          </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <!-- Content Wrapper END -->
                <!-- model -->
                
               
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apipaydexsolutio/public_html/jippay/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>