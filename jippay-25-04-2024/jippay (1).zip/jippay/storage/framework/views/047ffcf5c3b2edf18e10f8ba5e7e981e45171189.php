<?php echo $__env->make('user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Container START -->

            <div class="page-container">

                <!-- Content Wrapper START -->

                <div class="main-content">                   

                    <div class="row">

                        <div class="col-md-12 col-lg-12">

                            <div class="card">

                                <div class="card-body">

                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success mb-1 mt-1">

                                            <?php echo e(session('success')); ?>


                                        </div>
                                    <?php endif; ?>

                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5>Bank Accounts</h5>
                                        <div>
                                            <a href="<?php echo e(url('/user/add-bank')); ?>" class="btn btn-sm btn-primary">Add Account</a>
                                        </div>
                                    </div>

                                    <div class="m-t-30">

                                        <div class="table-responsive-md table-responsive-sm table-responsive">

                                            <table class="table table-hover table-bordered" id="datatable"> 

                                                <thead>

                                                    <tr>

                                                        <th>SI.NO</th>

                                                        <th>Beneficiary</th>

                                                        <th>Bank</th>
                                                        
                                                        <th>A/C No</th>                                                        

                                                        <th>IFSC</th>

                                                        <th>Action</th>

                                                    </tr>

                                                </thead>

                                                <tbody>
                                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($bank->id); ?></th>
                                                        <td><?php echo e($bank->cus_name); ?></td>
                                                        <td><?php echo e($bank->bank_name); ?></td>
                                                        <td><?php echo e($bank->acc_number); ?></td>
                                                        <td><?php echo e($bank->ifsc_code); ?></td>
                                                        <td>
                                                            <a class="btn btn-icon btn-success" href="<?php echo e(route('user.editBank',$bank->id)); ?>" title="Edit">
                                                                <i class="anticon anticon-edit"></i>
                                                            </a>
                                                            <a class="btn btn-icon btn-danger" href="<?php echo e(route('user.deleteBank',$bank->id)); ?>" title="Delete">
                                                                <i class="anticon anticon-delete"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>

                                            </table>

                                            

                                        </div>

                                        

                                    </div>

                                </div>

                            </div>

                        </div>

                       

                    </div>

                </div>

                <!-- Content Wrapper END -->

                <!-- model -->          

                

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<link href="https://cdn.datatables.net/v/dt/dt-1.13.5/datatables.min.css" rel="stylesheet">

<script src="https://cdn.datatables.net/v/dt/dt-1.13.5/datatables.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<script type="text/javascript">

    $(document).ready(function () {
        let table = new DataTable('#datatable');
    });



</script>



<?php echo $__env->make('user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apipaydexsolutio/public_html/jippay/resources/views/user/banklist.blade.php ENDPATH**/ ?>