<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Paydex</title>

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/fontawesome.min.css')); ?>" />

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/style.css')); ?> "/>

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/header.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/animate.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/slick.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/slick-theme.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets_front/css/login.css')); ?>">

</head>

<body>

    <section class="sign-in">

        <div class="container">

            <div class="signin-content row">

                <div class="col-lg-6 col-md-6">

                    <div class="signin-image">

                        <figure><img src="<?php echo e(asset('assets_front/images/signin-image1.jpg')); ?>" alt="sing up image"></figure>

                    </div>

                </div>

                <div class="col-lg-6 col-md-6">

                    <div class="login-form">

                        <h4>PayNow</h4>

                        <P> <span>Welcome Back !</span> <br>

                            Sign in to continue to PayNow.</P>

                            <?php if(session('success')): ?>

                                <div class="alert alert-success mb-1 mt-1">

                                    <?php echo e(session('success')); ?>


                                </div>

                            <?php endif; ?>

                        <form action="<?php echo e(url('authentication')); ?>" method="POST" enctype="multipart/form-data">

                            <?php echo csrf_field(); ?>

                            <div class="row">

                                <div class="col-lg-12">

                                    <div class="mb-3">

                                        <label for="exampleInputEmail1" class="form-label">Mobile</label>

                                        <input type="text" class="form-control" name="mobile" id="mobile"

                                            aria-describedby="emailHelp">

                                    </div>

                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="col-lg-12">

                                    <div class="mb-3">

                                        <label for="exampleInputPassword" class="form-label">Password</label>

                                        <input type="password" class="form-control" name="password" id="password"

                                            aria-describedby="passwordHelp">

                                    </div>

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            <button type="submit" class="sbtns">Login</button>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <script src="<?php echo e(asset('assets_front/js/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets_front/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets_front/js/slick.js')); ?>"></script>

    <script src="<?php echo e(asset('assets_front/js/script.js')); ?>"></script>



</body>



</html><?php /**PATH C:\xampp\htdocs\jippay\resources\views/Front/login.blade.php ENDPATH**/ ?>