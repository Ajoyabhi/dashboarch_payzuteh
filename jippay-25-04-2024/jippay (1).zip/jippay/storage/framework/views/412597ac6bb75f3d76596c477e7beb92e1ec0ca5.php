<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-container">

    <!-- Content Wrapper START -->

    <div class="main-content">

        <div class="page-header">

            <h2 class="header-title">Users</h2>

            <div class="header-sub-title">

                <nav class="breadcrumb breadcrumb-dash">

                    <a href="<?php echo e(url('/admin/dashboard')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>                    

                    <span class="breadcrumb-item active">Users</span>

                </nav>

            </div>

        </div>

        <div class="card">

            <div class="card-body">

                <?php if(session('success')): ?>

                    <div class="alert alert-success mb-1 mt-1">

                        <?php echo e(session('success')); ?>


                    </div>

                <?php endif; ?>

                <div class="row">

                    <div class="col-md-12 col-lg-12">                        

                        <div class="d-flex justify-content-between align-items-center">

                            <h5>Users</h5>

                            <div>

                                <a href="<?php echo e(url('/admin/add-user')); ?>" class="btn btn-sm btn-primary">Add User</a>

                            </div>

                        </div>

                            <div class="m-t-30">

                                <div class="table-responsive">

                                    <table class="table table-hover table-bordered">

                                        <thead>

                                            <tr>

                                                <th>Name</th>

                                                <th>Wallet Bal</th>

                                                <th>Mobile</th>

                                                <th>Email</th>

                                                <th>Status</th>

                                                <th>Api Status</th>
                                                <th>Technical issue</th>
                                                <th>Deactivated by Bank</th>
                                                <th>IserveU</th>
                                                <th>Vouch</th>
                                                <th>Action</th>

                                            </tr>

                                        </thead>

                                        <tbody>

                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>

                                                    <td><?php echo e($rows->name); ?></td>

                                                    <td><?php echo e($rows->wallet); ?></td>

                                                    <td><?php echo e($rows->mobile); ?></td>

                                                    <td><?php echo e($rows->email); ?></td>

                                                    <td>

                                                        <?php if($rows->status == 1): ?>

                                                            <button class="btn btn-sm btn-success" onClick="changeStatus(<?php echo e($rows->id); ?>,'DEACTIVE','status')">ACTIVE</button>

                                                        <?php else: ?>

                                                            <button class="btn btn-sm btn-danger" onClick="changeStatus(<?php echo e($rows->id); ?>,'ACTIVE','status')">DEACTIVE</button>

                                                        <?php endif; ?>

                                                    </td>

                                                    <td>

                                                        <?php if($rows->api_status == 1): ?>

                                                            <button class="btn btn-sm btn-success"  onClick="changeStatus(<?php echo e($rows->id); ?>,'DEACTIVE','API')">ACTIVE</button>

                                                        <?php else: ?>

                                                            <button class="btn btn-sm btn-danger"  onClick="changeStatus(<?php echo e($rows->id); ?>,'ACTIVE','API')">DEACTIVE</button>

                                                        <?php endif; ?>

                                                    </td>

                                                    <td>

                                                    <?php if($rows->tecnical_issue == 0): ?>

                                                        <button class="btn btn-sm btn-danger"  onClick="changeStatus(<?php echo e($rows->id); ?>,'ACTIVE','TECHNICAL')">DEACTIVE</button>

                                                    <?php else: ?>

                                                        <button class="btn btn-sm btn-success"  onClick="changeStatus(<?php echo e($rows->id); ?>,'DEACTIVE','TECHNICAL')">ACTIVE</button>

                                                    <?php endif; ?>

                                                    </td>
                                                    <td>
                                                        <?php if($rows->bank_deactive == 0): ?>
                                                            <button class="btn btn-sm btn-danger"  onClick="changeStatus(<?php echo e($rows->id); ?>,'ACTIVE','BYBANK')">DEACTIVE</button>
                                                        <?php else: ?>
                                                            <button class="btn btn-sm btn-success"  onClick="changeStatus(<?php echo e($rows->id); ?>,'DEACTIVE','BYBANK')">ACTIVE</button>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td>
                                                        <?php if($rows->iserveu == 0): ?>
                                                            <button class="btn btn-sm btn-danger"  onClick="changeStatus(<?php echo e($rows->id); ?>,'ACTIVE','iserveu')">DEACTIVE</button>
                                                        <?php else: ?>
                                                            <button class="btn btn-sm btn-success"  onClick="changeStatus(<?php echo e($rows->id); ?>,'DEACTIVE','iserveu')">ACTIVE</button>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td>
                                                        <?php if($rows->vouch == 0): ?>
                                                            <button class="btn btn-sm btn-danger"  onClick="changeStatus(<?php echo e($rows->id); ?>,'ACTIVE','vouch')">DEACTIVE</button>
                                                        <?php else: ?>
                                                            <button class="btn btn-sm btn-success"  onClick="changeStatus(<?php echo e($rows->id); ?>,'DEACTIVE','vouch')">ACTIVE</button>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td>                                                    

                                                        <a class="btn btn-icon btn-success" href="<?php echo e(url('admin/manage-user-charge/'.$rows->id)); ?>">

                                                            <i class="anticon anticon-plus"></i>

                                                        </a>

                                                        <button class="btn btn-icon btn-primary" data-toggle="modal" data-target="#setting_<?php echo e($rows->id); ?>">

                                                            <i class="anticon anticon-setting"></i>

                                                        </button>

                                                        <button class="btn btn-icon btn-warning" data-toggle="modal" data-target="#fund_<?php echo e($rows->id); ?>">

                                                            <i class="anticon anticon-money-collect"></i>

                                                        </button>

                                                    </td>

                                                </tr>



                                                <!-- model Stting-->

                                                <div class="modal fade" id="setting_<?php echo e($rows->id); ?>">

                                                    <div class="modal-dialog modal-dialog-scrollable">

                                                        <div class="modal-content">

                                                            <div class="modal-header">

                                                                <h5 class="modal-title" id="exampleModalScrollableTitle">Setting</h5>

                                                                <button type="button" class="close" data-dismiss="modal">

                                                                    <i class="anticon anticon-close"></i>

                                                                </button>

                                                            </div>

                                                                <div class="modal-body">

                                                                <form action="<?php echo e(url('admin/save-user-setting')); ?>" method="POST">

                                                                <?php echo csrf_field(); ?>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Lien Amount</label>

                                                                    <input type="text" class="form-control" name="lien" placeholder="Lien Amount" value="<?php echo e($rows->lien); ?>">

                                                                </div>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Rolling Reserve Amount</label>

                                                                    <input type="text" class="form-control" name="rolling_reserve" placeholder="Rolling Reserve Amount" value="<?php echo e($rows->rolling_reserve); ?>">

                                                                </div>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Payin Callback</label>

                                                                    <input type="text" class="form-control" name="payin_callback" placeholder="Payin Callback" value="<?php echo e($rows->payin_callback); ?>">

                                                                </div>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Payout Callback</label>

                                                                    <input type="text" class="form-control" name="payout_callback" placeholder="Payout Callback" value="<?php echo e($rows->payout_callback); ?>">

                                                                </div>

                                                                <input type="hidden" name="userid" value="<?php echo e($rows->id); ?>"/>

                                                                    

                                                                </div>

                                                                <div class="modal-footer">

                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                                                                    <button type="submit" class="btn btn-primary">Save</button>

                                                                </div>

                                                            </form>

                                                        </div>

                                                    </div>

                                                </div>

                                                <!-- model Fund-->

                                                <div class="modal fade" id="fund_<?php echo e($rows->id); ?>">

                                                    <div class="modal-dialog modal-dialog-scrollable">

                                                        <div class="modal-content">

                                                            <div class="modal-header">

                                                                <h5 class="modal-title" id="exampleModalScrollableTitle">User Fund</h5>

                                                                <button type="button" class="close" data-dismiss="modal">

                                                                    <i class="anticon anticon-close"></i>

                                                                </button>

                                                            </div>

                                                                <div class="modal-body">

                                                                <form action="<?php echo e(url('admin/update-user-fund')); ?>" method="POST">

                                                                <?php echo csrf_field(); ?>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Type</label>

                                                                    <select class="form-control" name="fund_type" required>

                                                                        <option value="CREDIT">CREDIT</option>

                                                                        <option value="DEBIT">DEBIT</option>

                                                                    </select>

                                                                </div>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Amount</label>

                                                                    <input type="text" class="form-control" name="amount" placeholder="Amount" required>

                                                                </div>

                                                                <div class="form-group">

                                                                    <label for="inputAddress">Remark</label>

                                                                    <input type="text" class="form-control" name="remark" placeholder="Remark" required>

                                                                </div>                                                                

                                                                <input type="hidden" name="userid" value="<?php echo e($rows->id); ?>"/>                                                                    

                                                                </div>

                                                                <div class="modal-footer">

                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                                                                    <button type="submit" class="btn btn-primary">Update Fund</button>

                                                                </div>

                                                            </form>

                                                        </div>

                                                    </div>

                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                            

                                        </tbody>

                                    </table>

                                    <?php echo $user->links(); ?>


                                </div>

                            </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<script>    



    function changeStatus(id,status,type){

        var csrfToken = $('meta[name="csrf-token"]').attr('content');



        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': csrfToken

            }

        });

        var url = '<?php echo e(url('/admin/update-users-status')); ?>';

        $.ajax({

            type: 'POST',

            url: url,

            data: {

                'id':id,

                'status':status,

                'type':type

            },

            success: function (response) {

               alert(response);

               location.reload();

            }

        });

            

    }



</script>

    

<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apipaydexsolutio/public_html/resources/views/admin/manage-user.blade.php ENDPATH**/ ?>