<?php echo $__env->make('user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Container START -->

            <div class="page-container">

                <!-- Content Wrapper START -->

                <div class="main-content">

                    <div class="row">

                        <div class="col-md-6 col-lg-3">

                            <div class="card">

                                <div class="card-body">

                                    <div class="media align-items-center">

                                        <div class="avatar avatar-icon avatar-lg avatar-gold">

                                            <i class="anticon anticon-dollar"></i>

                                        </div>

                                        <div class="m-l-15">

                                            <h6 class="m-b-0"><?php echo e($usersBalances); ?></h6>

                                            <p class="m-b-0 text-muted">Wallet balance</p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>



                        <div class="col-md-6 col-lg-3">

                            <div class="card">

                                <div class="card-body">

                                    <div class="media align-items-center">

                                        <div class="avatar avatar-icon avatar-lg avatar-blue">

                                            <i class="anticon anticon-line-chart"></i>

                                        </div>

                                        <div class="m-l-15">

                                            <h6 class="m-b-0"><?php echo e($totalTrades); ?></h6>

                                            <p class="m-b-0 text-muted">Number of Trades</p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        

                        <div class="col-md-6 col-lg-3">

                            <div class="card">

                                <div class="card-body">

                                    <div class="media align-items-center">

                                        <div class="avatar avatar-icon avatar-lg avatar-green">

                                            <i class="anticon anticon-arrow-up"></i>

                                        </div>

                                        <div class="m-l-15">

                                            <h6 class="m-b-0"><?php echo e($totalTopUp); ?></h6>

                                            <p class="m-b-0 text-muted">Payin</p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-6 col-lg-3">

                            <div class="card">

                                <div class="card-body">

                                    <div class="media align-items-center">

                                        <div class="avatar avatar-icon avatar-lg avatar-red">

                                            <i class="anticon anticon-arrow-down"></i>

                                        </div>

                                        <div class="m-l-15">

                                            <h6 class="m-b-0"><?php echo e($totalPayout); ?></h6>

                                            <p class="m-b-0 text-muted">Payout</p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-6 col-lg-3">

                            <div class="card">

                                <div class="card-body">

                                    <div class="media align-items-center">

                                        <div class="avatar avatar-icon avatar-lg avatar-green">

                                            <i class="anticon anticon-arrow-up"></i>

                                        </div>

                                        <div class="m-l-15">

                                            <h6 class="m-b-0"><?php echo e($todayTopUp); ?></h6>

                                            <p class="m-b-0 text-muted">Today Payin</p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-6 col-lg-3">

                            <div class="card">

                                <div class="card-body">

                                    <div class="media align-items-center">

                                        <div class="avatar avatar-icon avatar-lg avatar-red">

                                            <i class="anticon anticon-arrow-down"></i>

                                        </div>

                                        <div class="m-l-15">

                                            <h6 class="m-b-0"><?php echo e($todayPayout); ?></h6>

                                            <p class="m-b-0 text-muted">Today Payout</p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-12 col-lg-12">

                            <div class="card">

                                <div class="card-body">

                                    <div class="d-flex justify-content-between align-items-center">

                                        <h5>Recent Transactions</h5>

                                        <div>

                                            <a href="<?php echo e(url('/user/wallet-report')); ?>" class="btn btn-sm btn-primary">View All</a>

                                        </div>

                                    </div>

                                    <div class="m-t-30">

                                        <div class="table-responsive">

                                            <table class="table table-hover table-bordered">

                                                <thead>

                                                    <tr>

                                                        <th>Date</th>                                                        

                                                        <th>Type</th>

                                                        <th>Descrption</th>

                                                        <th>Amount</th>

                                                        <th>Wallet balance</th>
                                                        <th>Status</th>

                                                    </tr>

                                                </thead>

                                                <tbody>

                                                    <?php if(!empty($usertransaction)): ?>

                                                        <?php $__currentLoopData = $usertransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <tr>

                                                            <td><?php echo e($rows->created_at); ?></td>                                                            

                                                            <td>

                                                                <?php if($rows->type == "CREDIT"): ?>

                                                                    <button class="btn btn-icon btn-success">

                                                                        <i class="anticon anticon-arrow-up"></i>

                                                                    </button>

                                                                <?php else: ?>

                                                                    <button class="btn btn-icon btn-danger">

                                                                        <i class="anticon anticon-arrow-down"></i>

                                                                    </button>

                                                                <?php endif; ?>

                                                            </td>                                                                    

                                                            <td><?php echo e($rows->remark); ?></td>

                                                            <td><?php echo e($rows->amount); ?></td>     

                                                            <td><?php echo e($rows->walletBalance); ?></td> 
                                                            <td><?php echo e($rows->status); ?></td>                                           

                                                        </tr>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <?php endif; ?>

                                                </tbody>

                                            </table>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                       

                    </div>

                </div>

                <!-- Content Wrapper END -->

                <!-- model -->

                

               

<?php echo $__env->make('user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/taray7wz/public_html/jippay/resources/views/user/dashboard.blade.php ENDPATH**/ ?>